//#ifndef PHYSICS_h
//#define PHYSICS_h


#ifndef PhysicsList_h
#define PhysicsList_h 1


#include "G4VModularPhysicsList.hh"
#include "G4EmStandardPhysics.hh"
#include "G4OpticalPhysics.hh"
#include "G4EmstandardPhysics.hh"
#include "G4EmExtraPhysics.hh"
#include "G4HadronElasticPhysicsXS.hh"
#include "G4StoppingPhysics.hh"
#include "G4IonBinaryCascadePhysics.hh"
#include "G4IonTable.hh"
#include "G4HadronInelasticQBBC.hh"
#include "G4NeutronTrackingCut.hh"
#include "FTFP_BERT.hh"
#include "G4EmStandardPhysics_option4.hh"
#include "G4EmStandardPhysics_option1.hh"
#include "G4DecayPhysics.hh"
#include "G4VUserPhysicsList.hh"
#include "globals.hh"
#include "QBBC.hh"
#include "G4RadioactiveDecayPhysics.hh"

#include "G4HadronPhysicsQGSP_BIC.hh"
#include "G4IonElasticPhysics.hh"
#include "G4IonPhysicsXS.hh"
#include "G4Transportation.hh"
#include "G4RadioactiveDecay.hh"
#include "G4LivermorePhotoElectricModel.hh"
#include "G4LivermoreComptonModel.hh"
#include "G4PhotoElectricEffect.hh"
#include "G4ProcessManager.hh"
#include "G4GammaConversion.hh"
#include "G4ComptonScattering.hh"
#include "G4HadronElasticPhysicsHP.hh"
#include "G4HadronPhysicsQGSP_BIC_HP.hh"
#include "G4HadronInelasticProcess.hh"
#include "G4CascadeInterface.hh"
#include "G4VPhysicsConstructor.hh"
#include "globals.hh"


class MyPhysicsList : public G4VModularPhysicsList
{
public:
  MyPhysicsList();
  virtual ~MyPhysicsList();
  //override;
  /*
protected:
  // these methods Construct physics processes and register them
   virtual void ConstructParticle();
   virtual void ConstructProcess();
   */
};

#endif