#include "PhysicsList.hh"
#include "G4EmStandardPhysics.hh"
#include "G4SystemOfUnits.hh"


#include "G4UnitsTable.hh"
#include "G4ParticleTypes.hh"
#include "G4IonConstructor.hh"
#include "G4PhysicsListHelper.hh"
#include "G4Radioactivation.hh"
#include "G4NuclideTable.hh"
#include "G4LossTableManager.hh"
#include "G4UAtomicDeexcitation.hh"
#include "G4NuclearLevelData.hh"
#include "G4DeexPrecoParameters.hh"
#include "G4NuclideTable.hh"
#include "G4NuclideTable.hh"
#include "G4DeexPrecoParameters.hh"

MyPhysicsList::MyPhysicsList() : G4VModularPhysicsList() {

  // Define transportation process
  AddTransportation();

  //add for Decay ---
    SetDefaultCutValue(0.001 * m); // Set default cut value for production of secondary particles

  // mandatory for G4NuclideTable
  //
  G4NuclideTable::GetInstance()->SetThresholdOfHalfLife(0.1*picosecond);
  G4NuclideTable::GetInstance()->SetLevelTolerance(1.0*eV);

  //read new PhotonEvaporation data set 
  //
  G4DeexPrecoParameters* deex = 
  G4NuclearLevelData::GetInstance()->GetParameters();
  deex->SetCorrelatedGamma(true);
  deex->SetStoreAllLevels(false);
  deex->SetIsomerProduction(false);  
  deex->SetMaxLifeTime(G4NuclideTable::GetInstance()->GetThresholdOfHalfLife()
                  /std::log(2.));



    // Electromagnetic physics
    RegisterPhysics(new G4EmStandardPhysics());

    //new FTFP_BERT;


    //RegisterPhysics(new G4EmStandardPhysics_option1());
    //RegisterPhysics(new G4EmStandardPhysics_option4());
    RegisterPhysics(new G4OpticalPhysics());
    //G4cout << "<<< Reference Physics List QBBC"
    //       <<G4endl;
    //defaultCutValue = 0.7*mm;


    // Synchroton Radiation & GN Physics
    RegisterPhysics( new G4EmExtraPhysics() );

    // Decays
    RegisterPhysics( new G4DecayPhysics() );


    // Hadron Physics
    //RegisterPhysics( new G4HadronElasticPhysicsXS() );
    RegisterPhysics( new G4HadronElasticPhysicsHP() );
    RegisterPhysics( new G4StoppingPhysics() );
    RegisterPhysics( new G4HadronPhysicsQGSP_BIC_HP());

    RegisterPhysics( new G4IonPhysics() );

    //RegisterPhysics( new G4HadronInelasticQBBC());

    // Neutron tracking cut
    //RegisterPhysics( new G4NeutronTrackingCut() );


    RegisterPhysics(new G4RadioactiveDecayPhysics());
    G4RadioactiveDecay* radioactiveDecay = new G4RadioactiveDecay();
    radioactiveDecay->SetICM( true );
    radioactiveDecay->SetARM( true );

/*
    //G4PhysicsModelCatalog* physicsList = new GammNuclearPhysics("gamma"); // 사용자 정의 Physics List 생성
    //RegisterPhysics(physicsList); // Physics List 등록
    //RegisterPhysics( new G4PhysicsModelCatalog("gamma"));
    G4ProcessManager* pManager = G4Gamma::Gamma()->GetProcessManager();
    G4HadronInelasticProcess* process = new G4HadronInelasticProcess( "photonNuclear", G4Gamma::Definition() );
    G4CascadeInterface* bertini = new G4CascadeInterface();
    bertini->SetMaxEnergy(10*GeV);
    process->RegisterMe(bertini);
    pManager->AddDiscreteProcess(process);
    pManager->AddDiscreteProcess(new G4GammaConversion);
    pManager->AddDiscreteProcess(new G4ComptonScattering());
    pManager->AddDiscreteProcess(new G4PhotoElectricEffect());

    //RegisterPhysics( new G4HadronPhysicsQGSP_BIC());
    RegisterPhysics( new G4IonElasticPhysics());
    RegisterPhysics( new G4IonPhysicsXS());

    */


  
    //new QBBC;


}


MyPhysicsList::~MyPhysicsList()
{
}
/*
void MyPhysicsList::ConstructParticle()
{
    // Define particles here if needed
}

void MyPhysicsList::ConstructProcess()
{
    G4ProcessManager* pmanager = G4Gamma::Gamma()->GetProcessManager();
    
    // Construct processes for gamma
    pmanager->AddDiscreteProcess(new G4GammaConversion());
    pmanager->AddDiscreteProcess(new G4ComptonScattering());
    pmanager->AddDiscreteProcess(new G4PhotoElectricEffect());

    // Uncomment the following lines if you want to use Livermore models for gamma
    // pmanager->AddDiscreteProcess(new G4LivermoreGammaConversion());
    // pmanager->AddDiscreteProcess(new G4LivermoreCompton());
    // pmanager->AddDiscreteProcess(new G4LivermorePhotoElectric());
}*/